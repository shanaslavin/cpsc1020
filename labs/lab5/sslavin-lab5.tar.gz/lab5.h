/******************
Shana Slavin
sslavin
Lab 5
Lab Section 005
Nashrat Humaira
******************/

#ifndef LAB5_H
#define LAB5_H

void bubble_sort(int *, int);





#endif
