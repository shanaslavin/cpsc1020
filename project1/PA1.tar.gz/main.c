#include <stdio.h>
#include <stdlib.h>
#include "functions.h"


int main(int argc, char *argv[])
{
  /*Create any variables need*/



  /*1.  Create a file pointer for the file that you will read from
   *2.  Check to make sure the file pointer is opened sucessfully */




  /*Call printMenu() This starts the program.  The Selection returned will
   *determine the steps needed next.
   */





  /*After everything is complete you should free any remaining allocated memory
   *and close and open file pointers.*/



  return 0;

}
