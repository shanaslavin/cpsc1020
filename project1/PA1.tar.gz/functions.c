#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include <time.h>


/*Use this file to implement the functions you have listed in your header file*/
