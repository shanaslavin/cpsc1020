#include <stdio.h>
#include <stdlib.h>
#include "functions.h"


int main(int argc, char *argv[])
{

  /*Create any variables need*/

  //int *sizeOfBoard;
  int row = 0;
  int col = 0;


  /*1.  Create a file pointer for the file that you will read from
   *2.  Check to make sure the file pointer is opened sucessfully */
  FILE *inputPtr;
  inputPtr = fopen(argv[1], "r");
  if(inputPtr == NULL){
    printf("Error opening file.\n");
  }

  FILE *outputPtr;
  outputPtr = fopen(argv[2], "w");
  if(outputPtr == NULL){
    printf("Error opening file.\n");
  }


  fscanf(inputPtr, "%i", &row);
  fscanf(inputPtr, "%i", &col);
  printf(" %i %i\n", row, col);



  /*Call printMenu() This starts the program.  The Selection returned will
   *determine the steps needed next.
   */
  //printMenu();

  int **array = allocateMemory(row, col);
  int **outarr = allocateMemory(row, col);

  printMenu();

  readData(inputPtr, array, row, col);

  checkNeighbors(array, outarr, row, col);

  printOutput(outputPtr, outarr, row, col);

  printOut(outarr, row, col);
  //printMenu();


  /*After everything is complete you should free any remaining allocated memory
   *and close and open file pointers.*/



  return 0;

}
