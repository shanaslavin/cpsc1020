#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include <time.h>


/*Use this file to implement the functions you have listed in your header file*/
void readData(FILE* inputPtr, int **array, int row, int col){


  int i, j;

  for(i = 0; i < row; i++) {
    for(j = 0; j < col; j++) {
      fscanf(inputPtr, "%i", &array[i][j]);
      printf("%i ", array[i][j]);
    }
    printf("\n");
  }
}


void checkNeighbors(int** array, int** outarr, int row, int col){
  int currow, curcol;
  int mine = -1;

  for(currow = 0; currow < row; currow++){
    for(curcol = 0; curcol < col; curcol++){
      if(array[currow][curcol] == 1){
        outarr[currow][curcol] = mine;
      }
    }
  }

  for(currow = 0; currow < row; currow++){
    for(curcol = 0; curcol < col; curcol++){
      // If mine, check neighbors
      if(array[currow][curcol] <= 0){
        //top
          if(currow-1 >= 0){
            if(outarr[currow-1][curcol] < 0){
              outarr[currow][curcol]++;
            }
          }
          //below
          if(currow+1 < row){
            if(outarr[currow+1][curcol] < 0){
              outarr[currow][curcol]++;
            }
          }
          //below left
          if(curcol-1 > 0){
            if(currow-1 > 0){
              if(outarr[currow-1][curcol-1] < 0){
              outarr[currow][curcol]++;
              }
            }
          }
          //below right
          if(curcol+1 > 0){
            if(currow-1 > 0){
              if(outarr[currow-1][curcol+1] < 0){
              outarr[currow][curcol]++;
              }
            }
          }
        //right
          if(curcol-1 >= 0){
            if(outarr[currow][curcol-1] < 0){
              outarr[currow][curcol]++;
            }
          }
          //top left
          if(curcol+1 < row){
            if(currow+1 < col){
              if(outarr[currow+1][curcol+1] < 0){
              outarr[currow][curcol]++;
              }
            }
          }
          //top right
          if(curcol-1 > 0){
            if (currow+1 < col) {
              if(outarr[currow+1][curcol-1] < 0){
                outarr[currow][curcol]++;
              }
            }
          }
          //left
          if(curcol+1 < col){
            if(outarr[currow][curcol+1] < 0){
              outarr[currow][curcol]++;
            }
          }
      }
    }
  }
}

void printOutput(FILE* outputPtr, int **outarr, int row, int col){
  int i, j;

  for (i = 0; i < row; i++ ) {
    for(j = 0; j < col; j++){
      fprintf(outputPtr, "%i", outarr[i][j]);
    }
  }

}


void printOut(int **outarr, int row, int col){
  int i, j;

  printf("\n");

  for (i = 0; i < row; i++ ) {
    for(j = 0; j < col; j++){
      if(outarr[i][j] < 0){
        printf("X ");
      }
      else{
      printf("%i ", outarr[i][j]);
    }
  }
    printf("\n");
  }
}


int **allocateMemory(int row, int col){

  int i;
  int **arr;

  arr = (int **) malloc (row * sizeof(int *));
    for(i = 0; i < row; i++){
      arr[i] = (int *) malloc (col * sizeof(int));
    }
  return arr;
}




int printMenu(){

  int choice = 0;
  int loop = 0;

  printf("**************************************************************\n");
  printf("                Welcome to Avoid the Mines                    \n");
  printf("         Please choose one of the options below               \n");
  printf("         1: Read the board information from a file            \n");
  printf("         2: Randomly generate the board information           \n");
  printf("         3: Randomly generate the board and play basic        \n");
  printf("         4: Randomly generate the board in play advanced      \n");
  printf("                  Type 1, 2, 3, or 4 and return               \n");
  printf("**************************************************************\n");

  scanf("%d", &choice);

  while (choice != 1 && choice != 2 && choice != 3 && choice != 4) {
    printf("Cannot recognize user data. Please re-enter your input.\n");

    printf("**************************************************************\n");
    printf("                Welcome to Avoid the Mines                    \n");
    printf("         Please choose one of the options below               \n");
    printf("         1: Read the board information from a file            \n");
    printf("         2: Randomly generate the board information           \n");
    printf("         3: Randomly generate the board and play basic        \n");
    printf("         4: Randomly generate the board in play advanced      \n");
    printf("                  Type 1, 2, 3, or 4 and return               \n");
    printf("**************************************************************\n");

    scanf("%d", &choice);
  }

return (choice);

}

//void generateBoard(int, int, int** );


//void propogateGuess(int, int, int, int, int**, int**);


//void getHW(int*, int*);


void option1(FILE* inputPtr, FILE* outputPtr, int, int, int**, int**){


}


//void option2(FILE*, int, int, int**, int**);


//void option3(FILE*, int, int, int**, int**);


//void option3(FILE*, int, int, int**, int**);


//void option4(FILE*, int, int, int**, int**);


//void playBasicGame(int, int, int**);
//void playAdvanceGame(int,int, int**);
