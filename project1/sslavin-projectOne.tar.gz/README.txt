Shana Slavin
sslavin
CPSC 1020 Fall 2017
Due Date: September 29, 2017
Instructor: Dr. Yvon Feaster

I encountered many problems while working on this project. At first I did not
 know where exactly to start. I wasn't sure which program needed to be written
 first or in what order they should be tested in. The majority of my problems
 however were from the checkNeighbors function. Mostly because there were so
 many spots where something could go wrong. I had trouble deciding how I wanted
 to outline my code. Then I continuously kept getting segmentation faults which
 I required help from my lab instructors. While I did enjoy this project I wish
 I had more time after the test to work on this.
