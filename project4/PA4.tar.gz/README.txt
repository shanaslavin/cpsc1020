Shana Slavin and Paige Clemons
Project 4
Instructor: Yvon Feaster
CPSC 1020
Due: December 8, 2017

  I liked the working with a partner since we could bounce ideas off of each
other. We didn't encounter many problems except the first time we read in the
file, it read in the last customer twice. We went to a TA for help. Another
problem we had was with the calculations for greenbean. The program rounds
oddly and we asked you about it. You said not to worry about it since
everything else is correct and it is something with the program.
The final total is incorrect when done by hand. Other than that we did not
have many troubles. 
